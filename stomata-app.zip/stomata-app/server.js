import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import "dotenv/config";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(express.json({ limit: "15mb" })); // leaf photos as base64 can be a few MB
app.use(express.static(path.join(__dirname, "public")));

const PEOPLE_KG_O2_PER_YEAR = 166;

app.post("/api/analyze", async (req, res) => {
  const { data, mediaType } = req.body || {};
  if (!data || !mediaType) {
    return res.status(400).json({ error: "Missing image data or mediaType." });
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "Server is missing ANTHROPIC_API_KEY." });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: mediaType, data } },
              {
                type: "text",
                text:
                  "You are a field botanist analyzing a photo of a single leaf to identify the likely tree species and estimate that tree's gas exchange. " +
                  "Respond with ONLY raw JSON, no markdown fences, no preamble, matching exactly this shape:\n" +
                  "{\n" +
                  '  "is_leaf": boolean,\n' +
                  '  "common_name": string,\n' +
                  '  "scientific_name": string,\n' +
                  '  "confidence_percent": number (0-100),\n' +
                  '  "leaf_notes": string (1 short sentence on identifying features used),\n' +
                  '  "assumed_maturity": string (e.g. "mature, ~10-15m canopy" - state the size assumption plainly),\n' +
                  '  "co2_absorbed_kg_per_year": number,\n' +
                  '  "o2_produced_kg_per_year": number,\n' +
                  '  "people_days_of_oxygen": number (o2_produced_kg_per_year / ' +
                  PEOPLE_KG_O2_PER_YEAR +
                  " * 365),\n" +
                  '  "estimate_caveat": string (1 short sentence noting these are literature-average estimates)\n' +
                  "}\n" +
                  "If the photo does not clearly show a leaf, set is_leaf to false, zero the numeric fields, and explain what you see in leaf_notes.",
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Anthropic API error:", response.status, errText);
      return res.status(502).json({ error: "Upstream API error." });
    }

    const result = await response.json();
    const textBlock = result?.content?.find((b) => b.type === "text")?.text || "";
    const cleaned = textBlock.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned);
    res.json(parsed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to analyze the leaf. Try again." });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Stomata server running on http://localhost:${PORT}`));
