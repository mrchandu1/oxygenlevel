# Stomata — Leaf Scanner (standalone)

A small self-hosted version of the leaf scanner: a Node/Express backend
that holds your Anthropic API key, and a no-build-step HTML/React frontend.

## 1. Get an API key
Create one at https://console.anthropic.com (Settings → API Keys).
This is separate from a claude.ai login.

## 2. Set up locally
```bash
cd stomata-app
npm install
cp .env.example .env
# edit .env and paste your key into ANTHROPIC_API_KEY=
npm start
```
Open http://localhost:3000 — take or choose a leaf photo, tap "Analyze specimen."

## 3. How it's wired
- `public/index.html` — the whole frontend (React loaded from a CDN, JSX
  compiled in-browser by Babel standalone, styled with Tailwind's CDN
  build). No `npm run build` step, so it's easy to read and edit.
- `server.js` — the only place your API key lives. It receives the photo
  from the browser, calls `api.anthropic.com/v1/messages` with the key
  attached server-side, and returns the parsed result. The browser never
  sees the key.

## 4. Deploy it
Any host that runs a Node process works: Render, Railway, Fly.io, a
plain VPS, etc. General steps:
1. Push this folder to a git repo.
2. On your host, set the environment variable `ANTHROPIC_API_KEY` (and
   optionally `PORT`) in its dashboard/secrets — don't commit `.env`.
3. Set the start command to `npm install && npm start`.
4. Point your domain at the service; done.

## Notes
- The CDN/Babel frontend is great for getting this running fast. For a
  production app you'd normally want a real build step (Vite, etc.) for
  faster load times — happy to convert it if you get there.
- Cost: each scan is one Claude API call with an image, billed to your
  Anthropic account. Check current pricing at https://docs.claude.com.
