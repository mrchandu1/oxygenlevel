import os
import json
import base64
import streamlit as st
import anthropic

PEOPLE_KG_O2_PER_YEAR = 166

st.set_page_config(page_title="Stomata — Leaf Scanner", page_icon="🌿", layout="centered")

# ---------------------------------------------------------------------------
# Theme (forest field-guide look)
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;700&display=swap');

    .stApp {
        background: radial-gradient(ellipse at top, #1C2C22 0%, #16231C 55%, #121C16 100%);
    }
    .block-container { padding-top: 2.5rem; max-width: 480px; }

    .stomata-eyebrow {
        font-family: 'JetBrains Mono', monospace;
        font-size: 11px; letter-spacing: 0.18em; color: #7C9683;
    }
    .stomata-title {
        font-family: 'Fraunces', serif; font-weight: 600; font-size: 34px;
        color: #E9E4D3; line-height: 1.05; margin: 2px 0 6px 0;
    }
    .stomata-sub {
        font-family: 'Inter', sans-serif; font-size: 13.5px; color: #9AAB9C;
        line-height: 1.5; margin-bottom: 18px;
    }
    .stomata-card {
        background: #EDE6D3; border-radius: 18px; padding: 22px;
        box-shadow: 0 12px 30px -10px rgba(0,0,0,0.5); margin-top: 12px;
    }
    .stomata-specimen {
        font-family: 'JetBrains Mono', monospace; font-size: 10px;
        letter-spacing: 0.1em; color: #7C9683;
    }
    .stomata-name {
        font-family: 'Fraunces', serif; font-weight: 700; font-size: 22px;
        color: #2A2620; line-height: 1.1; margin: 2px 0 0 0;
    }
    .stomata-sci {
        font-family: 'Fraunces', serif; font-style: italic; font-size: 13.5px;
        color: #5C6B58; margin: 1px 0 0 0;
    }
    .stomata-notes {
        font-family: 'Inter', sans-serif; font-size: 12.5px; color: #5C5646;
        margin-top: 10px; line-height: 1.5;
    }
    .stomata-divider { border-top: 1px dashed #C7BC9F; margin: 16px 0; }
    .stomata-label {
        font-family: 'JetBrains Mono', monospace; font-size: 10px;
        letter-spacing: 0.1em; color: #7C9683; margin-bottom: 8px;
    }
    .stomata-stat-box {
        border-radius: 12px; padding: 12px; flex: 1;
        font-family: 'Inter', sans-serif;
    }
    .stomata-stat-value {
        font-family: 'JetBrains Mono', monospace; font-weight: 700;
        font-size: 19px; color: #2A2620;
    }
    .stomata-equiv {
        background: #2A3A2F; border-radius: 12px; padding: 10px 12px;
        margin-top: 12px; font-family: 'Inter', sans-serif; font-size: 12.5px;
        color: #C9DBC0; line-height: 1.4;
    }
    .stomata-caveat {
        font-family: 'Inter', sans-serif; font-size: 11px; color: #8C826A;
        margin-top: 12px; line-height: 1.4;
    }
    .stomata-footer {
        font-family: 'Inter', sans-serif; font-size: 11px; color: #5C6B58;
        margin-top: 28px; text-align: center; line-height: 1.5;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.markdown('<div class="stomata-eyebrow">🌿 FIELD SCANNER</div>', unsafe_allow_html=True)
st.markdown('<div class="stomata-title">Stomata</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="stomata-sub">Photograph a single leaf. We\'ll estimate the species and how much '
    'CO₂ that tree absorbs, and O₂ it releases, in a year.</div>',
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# API key
# ---------------------------------------------------------------------------
api_key = os.environ.get("ANTHROPIC_API_KEY") or st.secrets.get("ANTHROPIC_API_KEY", None)
if not api_key:
    st.error(
        "No ANTHROPIC_API_KEY found. Add it to `.streamlit/secrets.toml` locally, "
        "or in your Streamlit Cloud app's Settings → Secrets."
    )
    st.stop()

client = anthropic.Anthropic(api_key=api_key)

# ---------------------------------------------------------------------------
# Image input
# ---------------------------------------------------------------------------
tab_camera, tab_upload = st.tabs(["📷 Take photo", "🖼️ Choose photo"])
image_bytes = None
media_type = "image/jpeg"

with tab_camera:
    cam_file = st.camera_input("Point at a single leaf", label_visibility="collapsed")
    if cam_file is not None:
        image_bytes = cam_file.getvalue()
        media_type = cam_file.type or "image/jpeg"

with tab_upload:
    up_file = st.file_uploader("Choose a leaf photo", type=["jpg", "jpeg", "png", "webp"], label_visibility="collapsed")
    if up_file is not None:
        image_bytes = up_file.getvalue()
        media_type = up_file.type or "image/jpeg"

if image_bytes:
    st.image(image_bytes, caption="Specimen loaded", use_container_width=True)

analyze = st.button("🔍 Analyze specimen", type="primary", use_container_width=True, disabled=image_bytes is None)

# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------
PROMPT = (
    "You are a field botanist analyzing a photo of a single leaf to identify the likely tree species "
    "and estimate that tree's gas exchange. Respond with ONLY raw JSON, no markdown fences, no preamble, "
    "matching exactly this shape:\n"
    "{\n"
    '  "is_leaf": boolean,\n'
    '  "common_name": string,\n'
    '  "scientific_name": string,\n'
    '  "confidence_percent": number (0-100),\n'
    '  "leaf_notes": string (1 short sentence on identifying features used),\n'
    '  "assumed_maturity": string (e.g. "mature, ~10-15m canopy" - state the size assumption plainly),\n'
    '  "co2_absorbed_kg_per_year": number,\n'
    '  "o2_produced_kg_per_year": number,\n'
    f'  "people_days_of_oxygen": number (o2_produced_kg_per_year / {PEOPLE_KG_O2_PER_YEAR} * 365),\n'
    '  "estimate_caveat": string (1 short sentence noting these are literature-average estimates)\n'
    "}\n"
    "If the photo does not clearly show a leaf, set is_leaf to false, zero the numeric fields, "
    "and explain what you see in leaf_notes."
)

if analyze and image_bytes:
    with st.spinner("reading stomata patterns…"):
        try:
            b64 = base64.b64encode(image_bytes).decode("utf-8")
            response = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1000,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}},
                            {"type": "text", "text": PROMPT},
                        ],
                    }
                ],
            )
            raw_text = next((b.text for b in response.content if b.type == "text"), "")
            cleaned = raw_text.replace("```json", "").replace("```", "").strip()
            result = json.loads(cleaned)
        except json.JSONDecodeError:
            st.error("The scan didn't come back clean. Try again with a clearer, well-lit leaf photo.")
            result = None
        except Exception as e:
            st.error(f"Something went wrong calling the API: {e}")
            result = None

    if result:
        if not result.get("is_leaf"):
            st.markdown(
                f"""
                <div class="stomata-card">
                    <p style="font-family:'Inter',sans-serif; font-size:14px; color:#2A2620; line-height:1.5;">
                        <strong>That doesn't quite read as a leaf.</strong><br/>{result.get('leaf_notes','')}
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            confidence = round(result.get("confidence_percent", 0))
            co2 = round(result.get("co2_absorbed_kg_per_year", 0))
            o2 = round(result.get("o2_produced_kg_per_year", 0))
            days = round(result.get("people_days_of_oxygen", 0))

            st.markdown(
                f"""
                <div class="stomata-card">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                        <div>
                            <div class="stomata-specimen">SPECIMEN</div>
                            <div class="stomata-name">{result.get('common_name','Unknown')}</div>
                            <div class="stomata-sci">{result.get('scientific_name','')}</div>
                        </div>
                        <div style="width:92px;height:92px;border-radius:50%;
                                    background:conic-gradient(#79A94C {confidence}%, #D8CFB4 0);
                                    display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                            <div style="width:74px;height:74px;border-radius:50%;background:#EDE6D3;
                                        display:flex;flex-direction:column;align-items:center;justify-content:center;">
                                <span style="font-family:'JetBrains Mono',monospace;font-weight:700;font-size:19px;color:#2A2620;">{confidence}%</span>
                                <span style="font-family:'JetBrains Mono',monospace;font-size:8px;letter-spacing:0.06em;color:#7C9683;">MATCH</span>
                            </div>
                        </div>
                    </div>

                    <div class="stomata-notes">{result.get('leaf_notes','')}</div>
                    <div class="stomata-divider"></div>
                    <div class="stomata-label">ESTIMATED ANNUAL EXCHANGE · {result.get('assumed_maturity','')}</div>

                    <div style="display:flex; gap:12px;">
                        <div class="stomata-stat-box" style="background:#E1D9C0;">
                            <div style="font-size:10.5px;color:#7A6E4E;">💧 CO₂ absorbed</div>
                            <div class="stomata-stat-value">{co2}<span style="font-size:12px;font-weight:500;"> kg/yr</span></div>
                        </div>
                        <div class="stomata-stat-box" style="background:#D9E5CC;">
                            <div style="font-size:10.5px;color:#5C6B4E;">💨 O₂ released</div>
                            <div class="stomata-stat-value">{o2}<span style="font-size:12px;font-weight:500;"> kg/yr</span></div>
                        </div>
                    </div>

                    <div class="stomata-equiv">
                        ≈ enough oxygen to cover one person for <strong style="color:#E9E4D3;">{days} days</strong> a year.
                    </div>

                    <div class="stomata-caveat">{result.get('estimate_caveat','')}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

st.markdown(
    '<div class="stomata-footer">Estimates are literature averages by species and maturity —<br/>'
    "not a physical measurement of the exact tree.</div>",
    unsafe_allow_html=True,
)
