# Stomata — Leaf Scanner (Streamlit)

Python/Streamlit version of the leaf scanner. Take or upload a photo of a
leaf; Claude identifies the likely species and estimates the tree's yearly
CO₂ absorbed / O₂ released.

## 1. Get an API key
Create one at https://console.anthropic.com (Settings → API Keys).
This is separate from a claude.ai login, and may require adding billing.

## 2. Run it locally
```bash
cd stomata-streamlit
pip install -r requirements.txt

# add your key
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# edit .streamlit/secrets.toml and paste your real key in

streamlit run app.py
```
This opens automatically at http://localhost:8501.

## 3. Deploy it for free on Streamlit Community Cloud
1. Push this folder to a GitHub repo (don't commit `secrets.toml` — only
   `secrets.toml.example` should be in git).
2. Go to https://share.streamlit.io, sign in with GitHub.
3. Click **New app**, pick your repo, set the main file to `app.py`.
4. Before/after deploying, open **Settings → Secrets** on the app and paste:
   ```
   ANTHROPIC_API_KEY = "sk-ant-your-real-key"
   ```
5. Deploy. You'll get a live link like `https://your-app.streamlit.app`.

## Notes
- Each scan is one Claude API call with an image, billed to your Anthropic
  account — check current pricing at https://docs.claude.com.
- `st.camera_input` needs camera permission in the browser; if it doesn't
  prompt, use the "Choose photo" tab instead.
